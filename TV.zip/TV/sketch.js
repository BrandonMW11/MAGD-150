var power = 0;
var channel = 0;
var fr = 30;
var go = 1;
var ch1updown = 1;
var ballY = 410;
var ch3updown = 0;
var eye1 = 275;
var eye2 = 275;
var eye3 = 275;
var eye4 = 275;
function setup() {
    createCanvas(800, 800);
    ellipseMode(CENTER);
}

function draw() {
    frameRate(fr);
    background(158, 101, 5);
    fill(209);
    ellipse(500, 675, 100, 100);
    ellipse(350, 675, 100, 100);
    ellipse(200, 675, 100, 100);
    strokeWeight(10);
    line(185, 640, 185, 710);
    line(215, 640, 215, 710);
    strokeWeight(1);
    fill(0);
    rect(600, 625, 150, 50);
    triangle(540, 675, 475, 640, 475, 710);
    triangle(310, 675, 375, 640, 375, 710);
    if (power == 0) {
        fill(0);
        ellipse(675, 750, 50, 50);
        rect(50, 50, 700, 550, 20);
    } else {
        fill(209);
        ellipse(675, 750, 50, 50);
        if (channel == 0) {
            fill(209);
            rect(50, 50, 700, 550, 20);
        } else if (channel == 1) {
            ch1();
        } else if (channel == 2) {
            ch2();
        } else if (channel == 3) {
            ch3();
        }
    }
}

function mouseClicked() {
    if ((mouseX <= 750) && (mouseX >= 600) && (mouseY <= 675) && (mouseY >= 625)) {
        if (power == 0) {
            power = 1;
            channel = 0;
        } else {
            power = 0;
        }
    }
    if ((mouseX <= 550) && (mouseX >= 450) && (mouseY <= 725) && (mouseY >= 625)) {
        if (channel == 3) {
            channel = 1;
        } else {
            channel += 1;
        }
    }
    if ((mouseX <= 400) && (mouseX >= 300) && (mouseY <= 725) && (mouseY >= 625)) {
        if (channel <= 1) {
            channel = 3;
        } else {
            channel -= 1;
        }
    }
}

function keyTyped() {
    if ((mouseX <= 250) && (mouseX >= 150) && (mouseY <= 725) && (mouseY >= 625)) {
        if (key == 'p') {
            if (go == 1) {
                go = 0;
            } else {
                go = 1;
            }
        }
        if (key == 'f') {
            fr += 20;
        }
        if ((key == 's') && (fr > 10)) {
            fr -= 20;
        }
    }
}

function ch1() {
    fill(100);
    rect(50, 400, 700, 200, 0, 0, 20, 20);
    fill(255);
    rect(50, 50, 700, 350, 20, 20, 0, 0);
    if (go == 1) {
        if (ch1updown == 1) {
            ballY -= 1;
            if (ballY <= 150) {
                ch1updown = 0;
            }
        } else {
            ballY += 1;
            if (ballY >= 410) {
                ch1updown = 1;
            }
        }
    }
    fill(0);
    ellipse(400, ballY, 100, 100);
}

function ch2() {
    fill(255);
    rect(50, 50, 700, 550, 20);
    fill(209);
    rect(100, 100, 600, 450, 20);
    fill(0);
    ellipse(400, 250, 175, 175);
    ellipse(300, 250, 125, 125);
    ellipse(500, 250, 125, 125);
    strokeWeight(30);
    stroke(255);
    line(300, 250, 300, 300);
    line(400, 430, 400, 480);
    line(500, 280, 500, 330);
    line(300, 370, 300, 420);
    line(400, 275, 400, 325);
    line(500, 400, 500, 450);
    strokeWeight(1);
    stroke(0);
}

function ch3() {
    fill(209);
    rect(50, 50, 700, 550, 20);
    fill(0);
    rect(200, 400, 150, 200);
    rect(450, 400, 150, 200);
    rect(200, 210, 150, 115);
    ellipse(525, 300, 175, 175);
    fill(100);
    rect(225, 375, 100, 25);
    rect(475, 375, 100, 25);
    fill(255);
    ellipse(275, 325, 150, 150);
    ellipse(525, 325, 150, 150);
    if (go == 1) {
        if (ch3updown == 0) {
            eye1 += 1;
            eye2 += 1;
            if (eye1 >= 325) {
                ch3updown = 1;
            }
        } else if (ch3updown == 1) {
            eye1 -= 1;
            eye2 -= 1;
            if (eye1 <= 275) {
                ch3updown = 2;
            }
        } else if (ch3updown == 2) {
            eye3 += 1;
            eye4 += 1;
            if (eye3 >= 325) {
                ch3updown = 3;
            }
        } else if (ch3updown == 3) {
            eye3 -= 1;
            eye4 -= 1;
            if (eye3 <= 275) {
                ch3updown = 0;
            }
        }
    }
    strokeWeight(10);
    line(250, 375, 300, 375);
    line(500, 375, 550, 375);
    line(260, eye1, 260, 325);
    line(315, eye2, 315, 325);
    line(540, eye3, 540, 325);
    line(485, eye4, 485, 325);
    strokeWeight(1);
}