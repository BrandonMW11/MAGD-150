var osc;
var playing;
var freqSound;
var amp;
var sine;
var freq = 400;
var ping;
var capture;
var vidOn = 0;
var filtered = 0;

function preload() {
    ping = loadSound("Ping.wav");
    capture = createCapture();
    capture.hide();
}

function setup() {
    var cnv = createCanvas(600, 600);
    cnv.mousePressed(playOscillator);
    osc = new p5.Oscillator('sine');
    sine = new p5.SinOsc();
    sine.start();
}

function draw() {
    background(0);
    freqSound = constrain(map(mouseX, 0, width, 100, 500), 100, 500);
    amp = constrain(map(mouseY, height, 0, 0, 1), 0, 1);
    var hertz = map(mouseX, 0, width, 20.0, 440.0);
    sine.freq(hertz);
    stroke(204);
    for (var x = 0; x < width; x++) {
        var angle = map(x, 0, width, 0, TWO_PI * hertz);
        var sinValue = sin(angle) * 120;
        line(x, 0, x, height / 2 + sinValue);
    }
    if (playing) {
        // smooth the transitions by 0.1 seconds

        osc.freq(freqSound, 0.1);
        osc.amp(amp, 0.1);
    }
    if (vidOn == 1) {
        var aspectRatio = capture.height / capture.width;
        var h = width * aspectRatio;
        image(capture, 0, 0, width, h);
        push();
        if (filtered == 1) {
            filter(INVERT);
        }
        pop();
    }
}

function playOscillator() {
    // starting an oscillator on a user gesture will enable audio
    // in browsers that have a strict autoplay policy.
    // See also: userStartAudio();
    osc.start();
    playing = true;
}

function mouseReleased() {
    // ramp amplitude to 0 over 0.5 seconds
    osc.amp(0, 0.5);
    playing = false;
}

function keyTyped() {
    if (key == 's') {
        ping.play();
    } else if (key == 'v') {
        if (vidOn == 0) {
            vidOn = 1;
        } else {
            vidOn = 0;
        }
    } else if (key == 'f') {
        if (vidOn == 1) {
            if (filtered == 0) {
                filtered = 1;
            } else {
                filtered = 0;
            }
        }
    }
}