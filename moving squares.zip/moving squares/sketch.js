var onoff = 0;
var rectX1 = -100;
var rectX2 = 50;
var rectX3 = 200;
var rectX4 = 350;
var rectcol = 1;
function setup() {
    createCanvas(650, 650);
    frameRate(250);
}

function draw() {
    if (keyIsPressed == true) {
        onoff = 1;
    } else {
        onoff = 0;
    }
    if (onoff == 0) {
        background(255);
        textSize(32);
        fill(0);
        text('press and hold any key', 50, 300);
        border();
    } else {
        background(0);
        rectX1 += 1;
        rectX2 += 1;
        rectX3 += 1;
        rectX4 += 1;
        if (rectX1 >= 650) {
            rectX1 = -100;
        }
        if (rectX2 >= 650) {
            rectX2 = -100;
        }
        if (rectX3 >= 650) {
            rectX3 = -100;
        }
        if (rectX4 >= 650) {
            rectX4 = -100;
        }
        checkcolor();
        rect(rectX1, 50, 100, 100);
        rect(rectX2, 200, 100, 100);
        rect(rectX3, 350, 100, 100);
        rect(rectX4, 500, 100, 100);
        fill(255);
        border();
    }
}

function mouseClicked() {
    if (rectcol == 4) {
        rectcol = 1;
    } else {
        rectcol += 1;
    }
}

function checkcolor() {
    if (rectcol == 1) {
        fill(255, 0, 0);
    } else if (rectcol == 2) {
        fill(0, 0, 255);
    } else if (rectcol == 3) {
        fill(0, 255, 0);
    } else if (rectcol == 4) {
        fill(255, 255, 0);
    }
}

function border() {
    for (var i = 0; i <= 700; i += 100) {
        rect(i, 0, 50, 50);
        rect(i, 600, 50, 50);
    }
}